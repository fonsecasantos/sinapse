# Sinapse Consultoria Estratégica

Site institucional da Sinapse Consultoria Estratégica, especialista em consultoria pública, projetos incentivados e captação de recursos.

Publicado via Netlify com integração ao GitHub.
